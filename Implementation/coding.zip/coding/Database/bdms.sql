-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2019 at 06:54 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bdms`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2, '2019_06_10_165733_create_tbldonor_table', 1),
(4, '2019_06_12_165339_create_tbldonors_table', 2),
(5, '2019_06_16_160422_create_tblblood_group_table', 3),
(6, '2019_06_16_160926_create_contact_us_table', 3),
(7, '2019_06_16_161604_create_tblcontactinfo_table', 4),
(8, '2019_06_16_170128_create_tblcontactus_table', 5),
(9, '2019_06_16_171734_create_tblcontacts_table', 6),
(10, '2019_06_20_171319_create_user_table', 7),
(11, '2019_06_23_153907_create_tblpage_table', 8),
(12, '2019_06_24_114927_create_tbladmin_table', 9),
(13, '2019_06_24_120719_create_tbluser_table', 10),
(14, '2019_06_24_121159_create_tblusers_table', 11),
(15, '2019_06_24_131051_create_users_table', 12);

-- --------------------------------------------------------

--
-- Table structure for table `tblblood_group`
--

CREATE TABLE `tblblood_group` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bloodgroup` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblblood_group`
--

INSERT INTO `tblblood_group` (`id`, `bloodgroup`, `created_at`, `updated_at`) VALUES
(2, 'B+', NULL, NULL),
(3, 'O+', NULL, NULL),
(4, 'AB+', NULL, NULL),
(5, 'A-', NULL, NULL),
(6, 'B-', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactinfo`
--

CREATE TABLE `tblcontactinfo` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_id` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactnumber` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblcontactinfo`
--

INSERT INTO `tblcontactinfo` (`id`, `address`, `email_id`, `contactnumber`, `created_at`, `updated_at`) VALUES
(1, 'Kalanki,Kathmandu', 'sabingautam05@gmail.com', '48429542', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontacts`
--

CREATE TABLE `tblcontacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonenumber` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblcontacts`
--

INSERT INTO `tblcontacts` (`id`, `name`, `email`, `phonenumber`, `message`, `created_at`, `updated_at`) VALUES
(2, 'sdsasd', 'saaasd', '9865015566', 'assasaas', '2019-06-16 20:48:29', '2019-06-16 20:48:29'),
(5, 'Sabin Gauta,', 'sabingautam05@gmail.com', '986532145', 'I created one view page, there displaying data in a table by fetching from database. and i given Action drop down . Two options are there in the drop down. View/edit and Delete. When i select the edit button, the corresponding row should delete from the database. How can i write that code in laravel?. In normal php i know. Can any one help to write the code??. My view page is given below', '2019-06-21 07:26:19', '2019-06-21 07:26:19'),
(8, 'zxzx', 'zzX', 'zzXxcwcdw', 'sddwwd', '2019-06-23 11:47:09', '2019-06-23 11:47:09'),
(9, 'zxzx', 'zzX', 'zzXxcwcdw', 'sddwwd', '2019-06-23 11:47:09', '2019-06-23 11:47:09'),
(10, 'asdds', 'dsadsadsad', 'daads', 'dsadsa', '2019-06-23 11:47:41', '2019-06-23 11:47:41'),
(11, 'asdds', 'dsadsadsad', 'daads', 'dsadsa', '2019-06-23 11:47:41', '2019-06-23 11:47:41'),
(12, 'aassa', 'asasa', 'assasassasa', 'sasasas', '2019-06-23 11:48:54', '2019-06-23 11:48:54'),
(13, 'aassa', 'asasa', 'assasassasa', 'sasasas', '2019-06-23 11:48:54', '2019-06-23 11:48:54'),
(14, 'sa', '124', '1518', '561+89asasa', '2019-06-23 11:49:18', '2019-06-23 11:49:18'),
(15, 'sa', '124', '1518', '561+89asasa', '2019-06-23 11:49:18', '2019-06-23 11:49:18'),
(16, 'sa', '124', '1518', '561+89asasa', '2019-06-23 11:49:18', '2019-06-23 11:49:18'),
(17, 'sa', '124', '1518', '561+89asasa', '2019-06-23 11:49:19', '2019-06-23 11:49:19'),
(18, '12346', '561', 'ass', 'saddds', '2019-06-23 11:49:52', '2019-06-23 11:49:52'),
(19, '12346', '561', 'ass', 'saddds', '2019-06-23 11:49:52', '2019-06-23 11:49:52'),
(20, 'asasa', 'sasa', 'ass', 'sasasa', '2019-06-23 11:51:13', '2019-06-23 11:51:13'),
(21, 'asasddas', 'sabingautam05@gmail.com', '986532145', '123456', '2019-06-23 20:06:40', '2019-06-23 20:06:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbldonors`
--

CREATE TABLE `tbldonors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blood_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbldonors`
--

INSERT INTO `tbldonors` (`id`, `first_name`, `last_name`, `blood_group`, `address`, `age`, `phone_number`, `gender`, `email`, `created_at`, `updated_at`) VALUES
(16, 'admib', 'asdlas;n', 'A+', 'sdadjsab', 584, '8503', 'male', 'ashjhadskuas', '2019-06-17 01:14:14', '2019-06-17 01:14:14'),
(17, 'admib', 'asdlas;n', 'A+', 'sdadjsab', 584, '8503', 'male', 'ashjhadskuas', '2019-06-17 01:14:45', '2019-06-17 01:14:45'),
(18, 'admib', 'asdlas;n', 'A+', 'sdadjsab', 584, '8503', 'male', 'ashjhadskuas', '2019-06-17 01:15:55', '2019-06-17 01:15:55'),
(19, 'asdsas', 'sadas', 'A+', 'sasda', 98, '51891', 'female', '235269', '2019-06-17 01:31:31', '2019-06-17 01:31:31'),
(20, 'Sabin', 'Gautam', 'A+', 'Kalanki,Kathmandu', 20, '9860560109', 'male', 'sabingautam05@gmail.com', '2019-06-21 06:45:48', '2019-06-21 06:45:48'),
(21, 'Pradip', 'Dhakal', 'AB+', 'Basudhara,kathmandu', 20, '98605601089', 'female', 'asss@gmail.com', '2019-06-22 11:06:59', '2019-06-22 11:06:59'),
(22, 'Rupesh', 'Thapa', 'AB+', 'Basudhara,kathmandu', 20, '9860560108', 'male', 'demonicgautam@gmail.com', '2019-06-22 11:11:56', '2019-06-22 11:11:56'),
(23, 'Abiraj', 'Timlasina', 'AB+', 'kapan', 20, '9840779554', 'male', 'timasinaabiraj92gmail.com', '2019-06-23 00:51:37', '2019-06-23 00:51:37'),
(24, 'Rupesh', 'Thapa', 'AB+', 'Basudhara,kathmandu', 20, '9860560108', 'female', 'BDMS123@gmail.com', '2019-06-23 01:20:38', '2019-06-23 01:20:38'),
(26, 'aassa', 'sadsad', 'O-', 'asdsa', 12, '91', 'female', 'timasinaabiraj92gmail.com', '2019-06-23 11:34:01', '2019-06-23 11:34:01'),
(27, 'aassa', 'sadsad', 'O-', 'asdsa', 12, '91', 'female', 'timasinaabiraj92gmail.com', '2019-06-23 11:34:01', '2019-06-23 11:34:01'),
(28, 'saas', 'asads', 'B+', 'asdasd', 98652, '9840779554', 'female', 'demonicgautam@gmail.com', '2019-06-23 11:34:22', '2019-06-23 11:34:22'),
(29, 'saas', 'asads', 'B+', 'asdasd', 98652, '9840779554', 'female', 'demonicgautam@gmail.com', '2019-06-23 11:34:22', '2019-06-23 11:34:22'),
(30, 'Pradip', 'Gautam', 'AB+', 'Kalanki,Nepal', 23, '9860560109', 'female', 'timasinaabiraj92gmail.com', '2019-06-23 19:59:10', '2019-06-23 19:59:10'),
(31, 'Rupesh', 'Gautam', 'O-', 'Kalanki,Kathmandu', 20, '98605601089', 'male', 'BDMS123@gmail.com', '2019-06-23 20:16:45', '2019-06-23 20:16:45');

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pagename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contents` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`id`, `pagename`, `contents`, `created_at`, `updated_at`) VALUES
(1, 'About Us', 'Blood bank is a place where blood bag that is collected from blood donation events is stored in one place. The term “blood bank” refers to a division of a hospital laboratory where the storage of blood product occurs and where proper testing is performed to reduce the risk of transfusion related events.\r\n\r\nBDMS is a private organization that functions as a place to donate blood. It takes a charge to the person or patient that is in needs of blood. However, the money that they collected is not for the profit for them but for recover the expenses incurred in recruiting and educating donors. This is also to ensure that the blood transfusion is as safe as possible. In Lions Bank & Research Foundation, They will make sure the availability of blood stock in their blood bank. They also published the current status of blood stock in their website homepage. This is for them to keep the website visitor especially donor informed about the needs of blood. They also inform the donor and the public where and when is their next event. However, this blood bank does not provide any facility for the donor and the patient. Therefore, they cannot know how many times that they have donated their blood. As for the donor, they cannot know their blood screening result for each time they donate their blood. Without having this function in the system, the donor cannot monitor his or her health condition. This will make the donor become unaware of their health condition.\r\nBlood Donor Management System (BDMS) is a web based system that can assists the information of blood bag during its handling in the blood bank. With this system, the user of this system can key in the result of blood test that has been conducted to each of the blood bag received by the blood bank. The result of test will indicate whether the blood bag can be delivered to patient or not.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `name`, `email`, `password`, `admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'sabin', 'sabin@gmail.com', 'admin', '1', 'ssdksdsdskssssk ns', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'sabin', 'sabin@gmail.com', 'admin123455c428d8875d2948607f3e3fe134d71b4', '1', 'aasnbsa', '2019-06-23 18:15:00', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblblood_group`
--
ALTER TABLE `tblblood_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactinfo`
--
ALTER TABLE `tblcontactinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontacts`
--
ALTER TABLE `tblcontacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldonors`
--
ALTER TABLE `tbldonors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblblood_group`
--
ALTER TABLE `tblblood_group`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblcontactinfo`
--
ALTER TABLE `tblcontactinfo`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcontacts`
--
ALTER TABLE `tblcontacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbldonors`
--
ALTER TABLE `tbldonors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
