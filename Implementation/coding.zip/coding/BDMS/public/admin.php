<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: "Lato", sans-serif;
            transition: background-color .5s;
        }

        .sidenav {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;

        }

        .sidenav a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 18px;
            color: black;
            display: block;
            transition: 0.3s;
        }

        .sidenav a:hover {
            color: #3E3f3A;
        }

        .sidenav .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        #main {
            transition: margin-left .5s;
            padding: 30px;
            background: #1d2124;
            color: #9fcdff;
        }

        @media screen and (max-height: 500px) {
            .sidenav {padding-top: 15px;}
            .sidenav a {font-size: 15px;}
        }
    </style>
</head>
<body>

<div id="mySidenav" class="sidenav">

    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

                    <a href="dashboard" class="list-group-item list-group-item-action bg-light">Dashboard</a>
                    <a href="donorList" class="list-group-item list-group-item-action bg-light">Donor List</a>
                    <a href="BloodGroup" class="list-group-item list-group-item-action bg-light">Blood Group</a>
                    <a href="contactUs" class="list-group-item list-group-item-action bg-light">Manage Contact Us</a>
                    <a href="page" class="list-group-item list-group-item-action bg-light">Manage Pages</a>
                    <a href="contactInfo" class="list-group-item list-group-item-action bg-light">Manage Contact Info</a>
</div>

<div id="main">

    <h5>Blood Donor and Donation Management System</h5>
    <span style="font-size:20px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>
</div>

<script>
    function openNav() {
        document.getElementById("mySidenav").style.width = "300px";
        document.getElementById("main").style.marginLeft = "300px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.2)";

    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("main").style.margin= "0";

    }
</script>

</body>
</html>
