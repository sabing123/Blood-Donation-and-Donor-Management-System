<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin-DonorList</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Login Page</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('/css/login.css')); ?>" type="text/css"  rel="stylesheet">

    <link href="<?php echo e(url('css/admin/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">


    <!-- Custom styles for this template -->



</head>
<body>

<?php include ('C:\xampp\htdocs\BDMS\public\admin.php');?><br>


<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12 mainlist">

                <h2 class="page-title">Donors List</h2><hr>

                <!-- Zero Configuration Table -->
                <div class="panel panel-default">
                    <div class="panel-heading">Donors Info</div>
                    <div class="panel-body">
                        <?php echo $__env->make('./include/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="90%">
                            <thead>
                            <tr>

                                <th>#</th>
                                <th>Full Name</th>
                                <th>Blood Group</th>
                                <th>Address</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Mobile No.</th>
                                <th>Email</th>
                                <th>action </th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>#</th>
                                <th>Full Name</th>
                                <th>Blood Group</th>
                                <th>Address</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Mobile No.</th>
                                <th>Email</th>
                                <th>action </th>
                            </tr>
                            </tfoot>
                            <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($donor->first_name); ?> <?php echo e($donor->last_name); ?></td>
                                    <td><?php echo e($donor->blood_group); ?></td>
                                    <td><?php echo e($donor->address); ?></td>
                                    <td><?php echo e($donor->age); ?></td>
                                    <td><?php echo e($donor->gender); ?></td>
                                    <td><?php echo e($donor->phone_number); ?></td>
                                    <td><?php echo e($donor->email); ?></td>

                                    <td>
                                    
                                    
                                    
                                    
                                    
                                     
<br>
                                    <a href="donorList/<?php echo e($donor->id); ?>" onclick="return confirm('Do you want to delete');"> Delete</a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>



                    </div>
                </div>



            </div>
        </div>

    </div>
</div>
</div>
<!-- Bootstrap core JavaScript -->

<!-- Bootstrap core JavaScript -->




<!-- Loading Scripts -->













<script src="<?php echo e(url('C:\xampp\htdocs\BDMS\public\jquery\jquery.js')); ?>"></script>
<script src="<?php echo e(url('C:\xampp\htdocs\BDMS\public\js\bootstrap.bundle.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//adminSection/donorList.blade.php ENDPATH**/ ?>