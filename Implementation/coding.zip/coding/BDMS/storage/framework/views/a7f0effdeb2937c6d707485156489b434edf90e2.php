<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin-BloodGroup</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('/css/login.css')); ?>" type="text/css"  rel="stylesheet">

    <link href="<?php echo e(url('css/admin/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(url('/font/font-awesome.min.css')); ?>">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Custom styles for this template -->



</head>
<body>

<?php include ('C:\xampp\htdocs\BDMS\public\admin.php');?><br>


<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12 mainlist">

                <h2 class="page-title">Blood Group List</h2><hr>

                <!-- Zero Configuration Table -->
                <div class="panel panel-default">
                    <div class="panel-heading">Blood Group</div>
                    <div class="panel-body">
                        <?php echo $__env->make('./include/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="90%">
                            <thead>
                            <tr>

                                <th>#</th>

                                <th>Blood Group</th>
                                <th>Create Date</th>
                                <th>Action</th>

                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>#</th>

                                <th>Blood Group</th>
                                <th>Create Date</th>
                                <th>Action</th>


                            </tr>
                            </tfoot>
                            <tbody>

                            <?php $__currentLoopData = $BloodGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($blood->bloodgroup); ?></td>
                                    <td>12/12/2019</td>
                                    <td>
                                        <a href="BloodGroup/<?php echo e($blood->id); ?>"  onclick="return confirm('Do you want to delete');">
                                            <i class="material-icons">delete</i>

                                        </a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>



                    </div>
                </div>



            </div>
        </div>

    </div>
</div>
</div>

<!-- Bootstrap core JavaScript -->

<!-- Bootstrap core JavaScript -->
<script src="jquery/jquery.min.js"></script>

<script src="js/bootstrap.bundle.min.js"></script>

<!-- Loading Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/fileinput.js"></script>
<script src="js/chartData.js"></script>
<script src="js/main.js"></script>


<script src="<?php echo e(url('css/admin/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('css/admin/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//adminSection/BloodGroup.blade.php ENDPATH**/ ?>