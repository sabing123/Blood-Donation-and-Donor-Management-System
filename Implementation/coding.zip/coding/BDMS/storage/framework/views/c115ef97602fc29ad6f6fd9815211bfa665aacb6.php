<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin-Dashboard</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">


    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('/css/login.css')); ?>" type="text/css"  rel="stylesheet">

    <link href="<?php echo e(url('css/admin/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->



</head>
<body>

<?php include ('C:\xampp\htdocs\BDMS\public\admin.php');?><br>

<div class="ts-main-content">

    <div class="content-wrapper">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-12">

                    <center><h2 class="page-title">Dashboard</h2></center>
<hr>
                    <br>
                </div>
            </div>
        </div>
    </div>



    <div class="container">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4">
                    <div class="div2">)

                        <center>  <h1>8</h1> </center>

                        <center> <h3>List of Donor Register</h3></center><hr>
                        <a href="donorList"> Full Details </a>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="div2">
                        <center>  <h1>3</h1> </center>
                        <center> <h3>List of Blood Group</h3></center><hr>
                        <a href="BloodGroup"> Full Details </a>

                    </div>
                </div>

                <div class="col-md-4">
                    <div class="div2">
                        <center>  <h1>3</h1> </center>
                        <center> <h3>Total Queries</h3></center><hr>
                        <a href="contactUs"> Full Details </a>

                    </div>
                </div>

                </div>
            </div>
        </div>
    </div>
                </div>




            </div>
        </div>
    </div>


    <!-- /#wrapper -->
            <!-- Bootstrap core JavaScript -->

<!-- Bootstrap core JavaScript -->
<script src="jquery/jquery.min.js"></script>

<script src="js/bootstrap.bundle.min.js"></script>

<!-- Loading Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/fileinput.js"></script>
<script src="js/chartData.js"></script>
<script src="js/main.js"></script>





</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//adminSection/dashboard.blade.php ENDPATH**/ ?>