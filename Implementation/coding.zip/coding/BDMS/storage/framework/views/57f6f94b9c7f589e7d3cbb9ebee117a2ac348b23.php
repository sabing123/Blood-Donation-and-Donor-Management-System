<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Contact US</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BDMS-Search</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">


</head>
<body>
<div class="flex-center position-ref full-height">
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
<?php endif; ?>

<?php include ('navigation.php');?>
<!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3">Contact <small>Us</small></h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Contact Us</li>
        </ol>
    </div>
    <br>
    <div class="container">

        <div class="row">

            <div class="col-lg-8 contact">

                <p>We’re here to help and answer any question you might have. We look forward to hearing from you
                <center>🙂</center> </p>
                    <form method="POST" action="insert">
                        <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
                        <div class="row">
                            <div class="con1">
                                <label for="fname">Full Name</label>
                            </div>
                            <div class="con2">
                                <input type="text" id="fname" name="fname" placeholder="Your full name..">
                            </div>
                        </div>

                        <div class="row">
                            <div class="con1">
                                <label for="email">Email</label>
                            </div>
                            <div class="con2">
                                <input type="text" id="email" name="email" placeholder="Your Email..">
                            </div>
                        </div>
                        <div class="row">
                            <div class="con1">
                                <label for="phonenumber">phone number</label>
                            </div>
                            <div class="con2">
                                <input type="text" id="pnum" name="phonenumber" placeholder="Your contact number..">
                            </div>
                        </div>
                        <div class="row">
                            <div class="con1">
                                <label for="msg">Message</label>
                            </div>
                            <div class="con2">
                                <textarea id="msg" name="msg" placeholder="Write something.." style="height:200px"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <input type="submit" value="Send">
                        </div>
                    </form>
                </div>


            
             
                
                

                 
                 

                
                        

                
               
            

            </div>
        </div>
    </div>
    <br>
    <!-- Footer -->
    <footer class="py-5 bg-dark">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
        </div>
        <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="jquery/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>



</div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//contact.blade.php ENDPATH**/ ?>