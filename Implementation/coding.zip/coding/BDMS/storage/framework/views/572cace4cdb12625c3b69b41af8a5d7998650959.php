<?php if(session('success')): ?>
    <p class = "alert alert-sucess"> <?php echo e(session('success')); ?></p>
    <?php endif; ?>


<?php if(session('error')): ?>
    <p class = "alert alert-danger"> <?php echo e(session('error')); ?></p>
<?php endif; ?>

<?php if(session('warning')): ?>
    <p class = "alert alert-warning"> <?php echo e(session('warning')); ?></p>
<?php endif; ?>


<script>
    setTimeout(function () {
        $('.alert').slideUp();
    },3000);
</script>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views/session/notification.blade.php ENDPATH**/ ?>