<html>

<head>
    <title>Student Management | Edit</title>
</head>

<body>
<form action ="<?php echo e(url('/edit/'. $info[0]->id)); ?>" method = "POST">
    <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">

    <table>
        <tr>
            <td>adress</td>
            <td>
                <input type = 'text' name = 'address'
                       value = <?php echo e($info[0]->address); ?> />
            </td>
        </tr>
        <tr>
            <td colspan = '2'>
                <input type = 'submit' value = "Update" />
            </td>
        </tr>
    </table>
</form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//adminSection/contactinfoupdate.blade.php ENDPATH**/ ?>