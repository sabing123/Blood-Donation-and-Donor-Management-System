<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin-ContactInfo</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('/css/login.css')); ?>" type="text/css"  rel="stylesheet">

    <link href="<?php echo e(url('css/admin/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->



</head>
<body>

<?php include ('C:\xampp\htdocs\BDMS\public\admin.php');?><br>


<div class="Container">
    <div class="col-md-9">
        <div class="panel panel-default">
            <div class="panel-heading">Form fields</div>
            <div class="panel-body">



                <form action = "update" method = "POST">
                    <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
                    <center><h1>Update Contact Information</h1>
<br>
                        <?php $__currentLoopData = $cinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"> Address</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" name="address" id="address"> <?php echo e($info->address); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"> Email id</label>
                        <div class="col-sm-8">
                            <input type="email" class="form-control" name="email" id="email" value="<?php echo e($info->email_id); ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label"> Contact Number </label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" value="<?php echo e($info->contactnumber); ?>" name="contactno" id="contactno" required>
                        </div>
                    </div>

                    <div class="hr-dashed"></div>

                    <div class="form-group">
                        <div class="col-sm-8 col-sm-offset-4">

                            <button class="btn btn-primary" name="submit" type="submit" style="width: 25%;">Update</button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </form>
                    </div>
                </div>
             </div>
        </div>
    </div>
</center>
<!-- Bootstrap core JavaScript -->

<!-- Bootstrap core JavaScript -->
<script src="jquery/jquery.min.js"></script>

<script src="js/bootstrap.bundle.min.js"></script>

<!-- Loading Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/fileinput.js"></script>
<script src="js/chartData.js"></script>
<script src="js/main.js"></script>





</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//adminSection/contactInfo.blade.php ENDPATH**/ ?>