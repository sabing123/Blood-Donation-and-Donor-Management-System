<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Search</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BDMS-Search</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">


</head>
<body>
<div class="flex-center position-ref full-height">
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php include ('navigation.php');?>

    <!-- Page Content -->
        <div class="container">

            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Search a <small>Blood</small></h1>

            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Search</li>
            </ol>
        </div>
    <br>
    <div class="container">

        <div class="row">

            <div class="col-lg-12">

                <form action="/search" method="POST" role="search">
                    <?php echo e(csrf_field()); ?>

                    <label for="Blood Group">Blood Group</label>
                    <select id="BD" name="BG">
                        <option value="A-">A-</option>
                        <option value="AB-">AB-</option>
                        <option value="O-">O-</option>
                        <option value="B-">B-</option>
                        <option value="A+">A+</option>
                        <option value="AB+">AB+</option>
                        <option value="O+">O+</option>
                        <option value="B+">B+</option>
                    </select>
                <label for="add">Address</label>
                <input type="text" id="address" name="location" placeholder="Enter location..">

                 <button type="submit" class="btn btn-primary"> Search </button>


                    
                    
                        

                            
                                

                                    

                                    
                                        

                                            
                                        
                                        
                                        
                                        
                                        
                                    

                                    
                                        

                                    
                                
                            
                        
                    

                    <div class="container">
                        <?php if(isset($details)): ?>
                            <p> The Search results for your query <b> <?php echo e($query); ?> </b> are :</p>
                            <h2>Sample User details</h2>
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>


                    </div>
                </form>
            </div>
        </div>
    </div>
    <br>
    <!-- Footer -->
    <?php echo $__env->make('.include/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.container -->




    <!-- Bootstrap core JavaScript -->
    <script src="jquery/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>



</div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//search.blade.php ENDPATH**/ ?>