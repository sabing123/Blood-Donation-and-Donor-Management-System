<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin-Page</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('/css/login.css')); ?>" type="text/css"  rel="stylesheet">

    <link href="<?php echo e(url('css/admin/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->



</head>
<body>

<?php include ('C:\xampp\htdocs\BDMS\public\admin.php');?><br>


<div class="Container">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">Form fields</div>
            <div class="panel-body">



                <form action = "<?php echo e(url('/update/'. $pinfo[0]->id)); ?>" method = "POST">
                    <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
                    <center><h1>Update Contact Information</h1></center>
                    <br>
                    <?php echo $__env->make('./include/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form-group">
                        <div class="form-group">
                            <label class="col-sm-4 control-label"> page Name</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="pname" id="pname" value="<?php echo e($pinfo[0]->pagename); ?>" required>
                            </div>
                        </div>

                        <label class="col-sm-4 control-label"> Address</label>
                        <div class="col-sm-8">
                            <textarea class="form-control" name= "con" id="con" > <?php echo e($pinfo[0]->contents); ?></textarea>
                        </div>
                    </div>

                    <div class="hr-dashed"></div>

                    <div class="form-group">
                        <div class="col-sm-8 col-sm-offset-4">
<center>
                            <button class="btn btn-primary" name="submit" type="submit"  onclick="return confirm('Do you want to Update Contact Information');"style="width: 25%;">Update</button>
</center>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
</div>
</center>

<!-- Bootstrap core JavaScript -->

<!-- Bootstrap core JavaScript -->
<script src="jquery/jquery.min.js"></script>

<script src="js/bootstrap.bundle.min.js"></script>

<!-- Loading Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/fileinput.js"></script>
<script src="js/chartData.js"></script>
<script src="js/main.js"></script>





</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//adminSection/page.blade.php ENDPATH**/ ?>