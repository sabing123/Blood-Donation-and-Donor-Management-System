<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Become Donor</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Donor Registration</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">


</head>
<body >

    <?php include ('navigation.php');?><br>
        <!-- Page Content -->
        <div class="container">

            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Become a <small>Donor</small></h1>

            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Become a Donor</li>
            </ol>
        </div>


        <div class="container">
            <?php echo $__env->make('.include/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form action="store" method="POST" class="div" id="donor">

            <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">

            <label for="first_name">First Name</label>
            <input type="text" id="fname" name="first_name" placeholder="Your name..">

            <label for="last_name">Last Name</label>
            <input type="text" id="lname" name="last_name" placeholder="Your last name..">

            <label for="blood_group">Blood Group</label>
            <select id="blood_group" name="blood_group">
                <option value="A-">A-</option>
                <option value="AB-">AB-</option>
                <option value="O-">O-</option>
                <option value="B-">B-</option>
                <option value="A+">A+</option>
                <option value="AB+">AB+</option>
                <option value="O+">O+</option>
                <option value="B+">B+</option>

            </select>
            <label for="address">Address</label>
            <input type="text" id="add" name="address" placeholder="Your address..">

            <label for="age">age</label>
            <input type="number" id="age" name="age" placeholder="Your age.." min ="0">

            <label for="phone_number">Contact Number</label>
            <input type="text" id="mbl" name="phone_number" placeholder="Your contact number.." >

            <label for="gender">Gender</label>
            <select id="gen" name="gender">
                <option value="">Select Your Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>
            <label for="email">Email id</label>
            <input type="text" id="email" name="email" placeholder="Your Email..">


            <input type="submit" value="Become Donor">
        </form>
    </div>

<br>
<!-- Footer -->
    <?php echo $__env->make('.include/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Bootstrap core JavaScript -->
<script src="jquery/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>



</div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views/donor.blade.php ENDPATH**/ ?>