<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin-Contact Us</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('/css/login.css')); ?>" type="text/css"  rel="stylesheet">

    <link href="<?php echo e(url('css/admin/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->



</head>

<body>
<?php include ('C:\xampp\htdocs\BDMS\public\admin.php');?><br>

<p>


</p>

<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12 mainlist">

                <h2 class="page-title">Contact Us Queries</h2><hr>

                <!-- Zero Configuration Table -->
                <div class="panel panel-default">
                    <div class="panel-heading">Contact Us</div>
                    <div class="panel-body">
                        <?php echo $__env->make('./include/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="90%">
                            <thead>
                            <tr>

                                <th>#</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Message</th>
                                <th>Posting Date</th>
                                <th>action </th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>#</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Message</th>
                                <th>Posting Date</th>
                                <th>action </th>

                            </tr>
                            </tfoot>


                            <tbody>

                            <?php $__currentLoopData = $queries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($msg->email); ?></td>
                                    <td><?php echo e($msg->phonenumber); ?></td>
                                    <td><?php echo e($msg->message); ?></td>
                                    <td><?php echo e($msg->created_at); ?></td>

                                    <td>
                                        
                                            
                                            
                                        
                                        

                                        
                                        <a href="contactUs/<?php echo e($msg->id); ?>" onclick="return confirm('Do you want to delete');"> Delete</a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>



                    </div>
                </div>



            </div>
        </div>

    </div>
</div>
</div>



<!-- Bootstrap core JavaScript -->

<!-- Bootstrap core JavaScript -->
<script src="jquery/jquery.min.js"></script>

<script src="js/bootstrap.bundle.min.js"></script>

<!-- Loading Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="js/fileinput.js"></script>
<script src="js/chartData.js"></script>
<script src="js/main.js"></script>





</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views//adminSection/contactUs.blade.php ENDPATH**/ ?>