<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Search</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BDMS-Search</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">


</head>
<body>
<div class="flex-center position-ref full-height">

    <?php include ('navigation.php');?>

    <!-- Page Content -->
        <div class="container">

            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Search a <small>Blood</small></h1>

            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Search</li>
            </ol>
        </div>
    <br>
    <div class="container">

        <div class="row">

            <div class="col-lg-12">

                <form action="#" method="GET" role="search">
                    <?php echo e(csrf_field()); ?>

                    <label for="Blood Group">Blood Group</label>
                    <select id="BD" name="blood group">
                        <option value="">Select Blood Group</option>
                        <option value="A-">A-</option>
                        <option value="AB-">AB-</option>
                        <option value="O-">O-</option>
                        <option value="B-">B-</option>
                        <option value="A+">A+</option>
                        <option value="AB+">AB+</option>
                        <option value="O+">O+</option>
                        <option value="B+">B+</option>
                    </select>

                <label for="add">Address</label>
                <input type="text" id="address" name="location" placeholder="Enter location..">

                 <button type="submit" class="btn btn-primary"> Search </button>
<br>
<center>

                    <div class="col-md-8">
                        <?php echo $__env->make('.include/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        

                        

                            



                                

                                

                                

                                

                                

                            

                            

                                

                                    

                                    

                                    

                                    

                                    
                                

                            

                        


</center>



                </form>
            </div>
        </div>
    </div>
    <br>
    <!-- Footer -->
    <?php echo $__env->make('.include/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.container -->




    <!-- Bootstrap core JavaScript -->
    <script src="jquery/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>



</div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BDMS\resources\views/search.blade.php ENDPATH**/ ?>