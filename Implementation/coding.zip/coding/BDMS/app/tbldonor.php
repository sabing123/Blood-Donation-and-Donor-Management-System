<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

/**

 */
class tbldonor extends Model
{


    public static $createRules = [
            'first_name' => 'required|string|',
            'last_name' => 'required|string',
            'blood_group' => 'required|string',
            'address' => 'required|string',
            'age' => 'required|integer|min:20|max:60',
            'phone_number' => 'required|min:8|numeric|',
            'gender' => 'required|string',
            'email' => 'required|string|email|max:50'
    ];
}
