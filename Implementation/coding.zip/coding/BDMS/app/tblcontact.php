<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tblcontact extends Model
{
    public static $createRules = [
        'name' => 'required|string',
        'email' => 'required|string|email|max:255',
        'phonenumber' => 'required|string',
        'message' => 'required|string',

    ];
}
