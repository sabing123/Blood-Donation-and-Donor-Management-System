<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tblcontactinfo extends Model
{

    public static $createRules = [

        'address' => 'required|string',
        'email' => 'required|string|email|max:50',
        'contact' => 'required|string',
    ];
}
