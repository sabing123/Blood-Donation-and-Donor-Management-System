<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class filter extends Model
{
    public static $createRules = [

        'blood Group' => 'required||string',
        'location' => 'required|string'

    ];

}
