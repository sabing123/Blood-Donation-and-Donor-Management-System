<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class pageContoller extends Controller
{
    public function pageinformation(request $request)
    {

//              $users = donor::all()->get();
        $page = DB::select('select * from tblpage');
        return view('about' ,['page' => $page]);
    }

    public function index() {
        $pinfo = DB::select('select * from tblpage');
        return view('/adminSection/page',['pinfo'=>$pinfo]);
    }

    public function update(Request $request,$id) {
//        $pname = $request->input('name');
        $con = $request->input('con');

        DB::update('update tblpage set contents = ? where id = ?',[$con,$id]);
        return redirect('/adminSection/page') -> with('success','Page Information Has Edited.');


    }
}
