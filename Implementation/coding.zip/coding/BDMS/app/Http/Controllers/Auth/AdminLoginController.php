<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class AdminLoginController extends Controller
{

    public function __construct()
{
    //defining our middleware for this controller
    $this->middleware('guest:admin',['except' => ['logout']]);
}

    //function to show admin login form
    public function showLoginForm() {
        return view('auth.admin-login');
    }
    //function to login admins
    public function login(Request $request, $user) {
//        validate the form data
        try {
            $this->validate($request, [
                'email' => 'required|email',
                'password' => 'required|min:6'
            ]);
        } catch (ValidationException $e) {
        }


        //attempt to login the admins in
        if($user->admin == 1){
            return redirect('adminSection/dashboard');
        }else {
            return redirect('/login');
        }
    }

    public function logout()
    {
        Auth::guard('admin')->logout();

        return redirect('admin');
    }

}
