<?php

namespace App\Http\Controllers;

use App\filter;
use App\tbldonor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class search extends Controller
{
    public function select()

    {
        $data = DB::table('tbldonors')->paginate(5);

        return view('/search', compact('data'));

    }


    public function find(Request $request, tbldonor $user)
    {
        $validatedData = $request->validate(filter::$createRules);

        $data = DB::table('tbldonors');

        if( $request-> location){

            $data = $data->where('blood_group', 'LIKE', "%" . $request->bloodgroup . "%")
                        ->where('address', 'LIKE', "%" . $request->location . "%");
            ;

        }

//        if( $request->location){
//
//            $data = $data->where('address', 'LIKE', "%" . $request->location . "%");
//
//        }


        $data = $data->paginate(5);

        return view('/search', compact('data'));

    }

}
