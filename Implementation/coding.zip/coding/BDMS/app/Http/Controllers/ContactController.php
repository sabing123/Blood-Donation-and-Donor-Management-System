<?php

namespace App\Http\Controllers;
use App\tblcontact;
use App\tblcontactinfo;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ContactController extends Controller
{

    public function queries(request $request)
    {

//              $users = donor::all()->get();
        $queries = DB::select('select * from tblcontacts');
        return view('/adminSection/contactUs' ,['queries' => $queries]) -> with('count',1) ;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
  //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function insert(Request $request)
    {
      $validatedData = $request->validate(tblcontact::$createRules);

        $contact = new tblcontact();
        $contact->name = input::get("name");
        $contact->email = input::get("email");
        $contact->phonenumber = input::get("phonenumber");
        $contact->message = input::get("message");

        $contact->save();

        return redirect('/contact')-> with('success','Message Has Been Send Successfully......');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $queries = DB::delete('delete from tblcontacts where id = ?',[$id]);
        return redirect('/adminSection/contactUs')-> with('success','Message Has Been Removed Successfully......');
    }

}
