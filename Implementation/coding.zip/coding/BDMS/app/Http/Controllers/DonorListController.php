<?php

namespace App\Http\Controllers;

use App\donor;
use App\tbldonor;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;

class DonorListController extends Controller
{

    public function index()
    {
        return view('/adminSection/donorList');
    }

    public function donorlist(request $request)
    {

        $users = DB::select('select * from tbldonors');
            return view('/adminSection/donorList' ,['users' => $users]) -> with('count',1);
    }

    public function listinfo()
    {

        $dinfo = DB::select('select * from tbldonors where id = id order by rand() limit 6' );
        return view('/welcome' ,['info' => $dinfo]);
    }



    public function destroy($id) {
        $donor = DB::delete('delete from tbldonors where id = ?',[$id]);
        return redirect('/adminSection/donorList') -> with('success','Donor Information Has Removed from List.');
    }
//
//    public function search(request $request)
//    {
//        $search = $request -> get ('search');
//        $posts = DB::table('tbldonors') -> where('address', 'like','%'.$search.'%')->paginate(5);
//        return view('/search',['posts' => $posts]);
//
//    }

}

