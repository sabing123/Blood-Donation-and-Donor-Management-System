<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;


class bloodGroup extends Controller
{
    public function BloodGroupList()
    {


        $BloodGroups = DB::select('select * from tblblood_group');
        return view('/adminSection/BloodGroup' ,['BloodGroups' => $BloodGroups]) -> with('count',1);
    }


//    public function show($id) {
//        $users = DB::select('select * from tblblood_group where id = ?',[$id]);
//        return view('/adminSection/bloodGroupUpdate',['BloodGroups' => $BloodGroups]);
//    }
//    public function edit(Request $request,$id) {
//        $BG = $request->input('bloodgroup');
//
////$data=array('first_name'=>$first_name,"last_name"=>$last_name,"city_name"=>$city_name,"email"=>$email);
////DB::table('student')->update($data);
//// DB::table('student')->whereIn('id', $id)->update($request->all());
//        DB::update('update tblblood_group set bloodgroup = ? where id = ?',[$BG,$id]);
//        echo "Record updated successfully.
//";
//        echo 'Click Here to go back.';
//    }




    public function destroy($id) {
        $BloodGroups = DB::delete('delete from tblblood_group where id = ?',[$id]);
        return redirect('/adminSection/BloodGroup')-> with('success','Blood Group Has Removed from List.');
    }


}
