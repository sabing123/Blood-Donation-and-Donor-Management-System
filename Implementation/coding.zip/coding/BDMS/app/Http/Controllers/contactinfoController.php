<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use app\tblcontactinfo;


class contactinfoController extends Controller
{
    public function contactinformation(request $request)
    {

//              $users = donor::all()->get();
        $contact = DB::select('select * from tblcontactinfo');
        return view('contact' ,['contact' => $contact]);
    }

    public function index() {
        $info = DB::select('select * from tblcontactinfo');
        return view('/adminSection/contactinfo',['info'=>$info]);
    }



    public function edit(Request $request,$id) {

     //   $validatedData = $request->validate(tblcontactinfo::$createRules);

        $address = $request->input('address');
        $email = $request->input('email');
        $number = $request->input('contact');
        DB::update('update tblcontactinfo set address = ?,email_id = ?,contactnumber = ? where id = ?',[$address,$email,$number,$id]);

        return redirect('/adminSection/contactInfo') -> with('success','Contact Information Has Edited.');


    }

}
