<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/donor', function () {
    return view('donor');
});


Route::get('/about', function () {
    return view('about');
});

Route::get('/search', function () {
    return view('search');
});

Route::get('/contact', function () {
    return view('contact');
});

Route::get('/mannual', function () {
    return view('/mannual');
});

Route::get('/candonateinfo', function () {
    return view('candonateinfo');
});

Route::get('/adminSection/index', function () {
    return view('/adminSection/index');
});

Route::get('/adminSection/index', function () {
    return view('/adminSection/index');
});



//route for donor register

//Route::get('/index','InsertDonorController@index');
Route::get('/index','InsertDonorController@index')->name('message');
Route::POST('/store','InsertDonorController@store');
//Route::get('/index/', 'LabelController@index');



//rouote for contact us form
Route::POST('/insert','ContactController@insert');

//FOR ADMIN ROUTING

Route::get('/index','adminlogin@index');

Route::get('/adminSection/dashboard', function () {
    return view('/adminSection/dashboard');
});

Route::get('/adminSection/donorList', function () {
    return view('/adminSection/donorList');
});

Route::get('/adminSection/BloodGroup', function () {
    return view('/adminSection/BloodGroup');
});

Route::get('/adminSection/contactUs', function () {
    return view('/adminSection/contactUs');
});

Route::get('/adminSection/page', function () {
    return view('/adminSection/page');
});

Route::get('/adminSection/contactInfo', function () {
    return view('/adminSection/contactInfo');
});

// retriving data for user

Route::get('/','DonorListController@listinfo');


//retriving data for admin
Route::get('/adminSection/donorList','DonorlistController@donorlist');
Route::get('/adminSection/BloodGroup','BloodGroup@BloodGroupList');
Route::get('/adminSection/contactInfo','contactinfoController@info');
Route::get('/adminSection/contactUs','ContactController@queries');
Route::get('/adminSection/page','pageContoller@pageinfo');



Route::get('/contact','contactinfoController@contactinformation');
Route::get('/about','pageContoller@pageinformation');
//Deleting data from database

Route::get('/adminSection/donorList/{id}','DonorListController@destroy');

//Deleting Blood Group from database
Route::get('/adminSection/BloodGroup/{id}','bloodgroup@destroy');

//Deleting Send Message from database
Route::get('/adminSection/contactUs/{id}','ContactController@destroy');


//updating contact info data
Route::get('/adminSection/contactInfo','contactinfoController@index');
Route::post('edit/{id}','contactinfoController@edit');


Route::get('/adminSection/page','pageContoller@index');
Route::post('update/{id}','pageContoller@update');

//sreaching function
Route::get('/search', 'search@select');
Route::get('/search', 'search@find')->name('blood_search');



//admin route for our multi-auth system

Route::prefix('admin')->group(function () {
    Route::get('/', 'AdminController@index')->name('/adminSection/dashboard');
    Route::get('/login', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');
    Route::post('/login', 'Auth\AdminLoginController@login')->name('admin.login.submit');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


