<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Search</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BDMS-Search</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">


</head>
<body>
<div class="flex-center position-ref full-height">

    <?php include ('navigation.php');?>

    <!-- Page Content -->
        <div class="container">

            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3">Search a <small>Blood</small></h1>

            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Search</li>
            </ol>
        </div>
    <br>
    <div class="container">

        <div class="row">

            <div class="col-lg-12">

                <form action={{url:: blood_search}} method="GET" role="search">
                    {{ csrf_field() }}
                    <label for="Blood Group">Blood Group</label>
                    <select id="BD" name="blood group">
                        <option value="">Select Blood Group</option>
                        <option value="A-">A-</option>
                        <option value="AB-">AB-</option>
                        <option value="O-">O-</option>
                        <option value="B-">B-</option>
                        <option value="A+">A+</option>
                        <option value="AB+">AB+</option>
                        <option value="O+">O+</option>
                        <option value="B+">B+</option>
                    </select>

                <label for="add">Address</label>
                <input type="text" id="address" name="location" placeholder="Enter location..">

                 <button type="submit" class="btn btn-primary"> Search </button>
<br>
<center>

                    <div class="col-md-8">
                        @include('.include/message')



                        <div class="row">
                            @foreach($data as $pep)

                                <div class="col-lg-4 col-md-6 mb-4">
                                    <div class="card h-100">

                                        <a href="#"><img class="card-img-top" src="images/blood-donor.jpg" alt="blood-donor"></a>

                                        <div class="card-body">
                                            <h4 class="card-title">

                                                <a href="#">{{ $pep->first_name }} {{ $pep->last_name }}</a>
                                            </h4>
                                            <h6><b>Gender:</b> {{ $pep->gender }}</h6>
                                            <h6><b>Blood Group:</b> {{ $pep->blood_group }}</h6>
                                            <h6><b>Location:</b> {{ $pep->address }}</h6>
                                            <h6><b>Contact No:</b> {{ $pep->phone_number }}</h6>
                                        </div>

                                        <div class="card-footer">
                                            <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>

                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

</center>



                </form>
            </div>
        </div>
    </div>
    <br>
    <!-- Footer -->
    @include('.include/footer')
        <!-- /.container -->




    <!-- Bootstrap core JavaScript -->
    <script src="jquery/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>



</div>
</div>
</body>
</html>
