
<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    #mainContent {
    border: 1px solid black;
        margin: 10px;
        padding: 20px;
        background: #3E3f3A;
        color: white;
    }
    #mainContent a{
        color: white;
        float: right;
        position: fixed;
        margin-left: 1250px;
        text-decoration: none;
    }
</style>
<body>

<div id="mainContent">



<a href="index.php">&larr; back</a>
    <h3>Who Can Donate</h3>

    <p>Accident &amp; Injury– Can donate if otherwise healthy.</p>
    <p>Accupunture– Postpone donation for one year.</p>
    <p>Aids– Cannot donate.</p>
    <p>Allergies– Can donate if mild and require no treatment.</p>
    <p>Alcohol– Postpone donation if consumed alcohol in last 12 hours.</p>
    <p>Anaemia– Postpone donation.</p>
    <p>Arthiritis– Can donate if mild and not on medication.</p>
    <p>Asthama– Can donate if mild. Those with severe asthama requiring regular treatment cannot donate.</p>
    <p>Blood Pressure– Acceptable range is 160/90 to 110/70. Not to donate if on medication.</p>
    <p>Bronchitis– Postpone donation till 4 weeks after recovery.</p>
    <p>Cancer– Cannot donate.</p>
    <p>Cold and Sore Throat– May not donate for first 24 hours into the condition. Can donate after 24 hours if feeling well enough to donate.</p>
    <p>Chicken Pox– Postpone donation till 4 weeks after recovery.</p>
    <p>Cholesterol– Can donate if on diet control. Not to donate if under treatment.</p>
    <p>Colitis– Cannot donate.</p>
    <p>Colostomy– Cannot donate</p>
    <p>Dementia– Cannot donate</p>
    <p>Dental Work– Can donate even if recent case of minor dental work like dental cleaning, fillings and extractions. Postpone donation for 72 hours if undergone oral surgery.</p>
    <p>Dengue– Postpone donation till 4 weeks after recovery.</p>
    <p>Dermatitis– Can donate if mild. Postpone donation if severe.</p>
    <p>Diabetes– Can donate if treating by diet control. Postpone donation if under medication.</p>
    <p>Diarrhoea– Postpone donation till 3 weeks after recovery.</p>
    <p>Drug Abuse– Cannot donate.</p>
    <p>Ear Piercing– Can donate if done by physician or using ear piercing gun with sterile supplies. Else postpone for one year.</p>
    <p>Eczema– Can donate if mild. Postpone donation if severe.</p>
    <p>Electrolysis– Postpone donation for one year.</p>
    <p>Emphysema– Can not donate.</p>
    <p>Filariasis– Cannot donate.</p>
    <p>Food Poisoning– Postpone donation for one week after recovery.</p>
    <p>Gastroenteritis– Postpone donation for one week after recovery.</p>
    <p>Gall Stone– Can donate if not on treatment.</p>
    <p>Genital Herpes– Postpone donation for 4 weeks after recovery.</p>
    <p>Gonorrhoea/Syphillis– Postpone donation for 1 year after recovery.</p>
    <p>Gout Cannot donate.</p>
    <p>Hepatitis– Can not donate if having history of viral hepatitis after 11 years of age. However can donate if history of hepatitis pertaining to mononucleosis or CMV infection.</p>
    <p>Leprosy– Cannot donate.</p>
    <p>Malaria– Postpone donation for 3 years after recovery.</p>
    <p>Mensuration– Can donate.</p>
    <p>Postrate– Cannot donate.</p>
    <p>Pregnancy– Can donate after 6 weeks of full term normal delivery. Can donate 6 weeks after termination in third trimester. Those with first or second trimester miscarriage can donate.</p>
    <p>Sickle Cell Trait– Cannot donate.</p>
    <p>Smoker– Can Donate.</p>
    <p>Spondylosis– Can donate if feeling fit and not under treatment.</p>
    <p>Stroke– Cannot donate.</p>
    <p>Syphilis– Cannot donate.</p>
    <p>Tattoo– Postpone donation for one year.</p>
    <p>Thyroid– For Hypothyroid can donate if feeling well and euthyroid on thyroxine for six months. For Hyperthyroid cannot donate until euthyroid for six months.</p>
    <p>Transfusion– Postpone donation by one year if undergone transfusion with blood products. However can donate if undergone autologous transfusion.</p>
    <p>Tuberculosis– Cannot donate till 2 years after complete cure.</p>
    <p>Viral Infection– Can donate after cure and off treatment.</p>
    <p>Worms– Can donate after cure.</p>

</div>
</body>
</html>
