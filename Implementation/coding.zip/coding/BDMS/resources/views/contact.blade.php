<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Contact US</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BDMS-Search</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/shop-homepage.css" rel="stylesheet">


</head>
<body>
<div class="flex-center position-ref full-height">

<?php include ('navigation.php');?>
<!-- Page Content -->
    <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3">Contact <small>Us</small></h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Contact Us</li>
        </ol>
    </div>
    <br>
    <div class="container">

        <div class="row">

            <div class="col-lg-7 contact">
                @include('.include/message')


                <p>We’re here to help and answer any question you might have. We look forward to hearing from you
                <center>🙂</center> </p>
                    <form method="POST" action="insert">
                        <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
                        <div class="row">
                            <div class="con1">
                                <label for="fname">Full Name</label>
                            </div>
                            <div class="con2">
                                <input type="text" id="fname" name="name" placeholder="Your full name..">
                            </div>
                        </div>

                        <div class="row">
                            <div class="con1">
                                <label for="email">Email</label>
                            </div>
                            <div class="con2">
                                <input type="text" id="email" name="email" placeholder="Your Email..">
                            </div>
                        </div>
                        <div class="row">
                            <div class="con1">
                                <label for="phonenumber">Phone No.</label>
                            </div>
                            <div class="con2">
                                <input type="text" id="pnum" name="phonenumber" placeholder="Your contact number..">
                            </div>
                        </div>
                        <div class="row">
                            <div class="con1">
                                <label for="msg">Message</label>
                            </div>
                            <div class="con2">
                                <textarea id="msg" name="message" placeholder="Write something.." style="height:200px"></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <input type="submit" value="Send">
                        </div>
                    </form>
                </div>

            @foreach ($contact as $c)
             <div class="col-lg-4 info">
                <h4>Contact Details</h4>
                 <label> <h6>Blood Donation Management System </h6> </label><br>

                 <label> Address :</label>
                 <label>{{ $c->address}}</label><br>

                 <label> Email :</label>
                 <label>{{ $c->email_id }}</label>
<br>
                <label> Phone :</label>
                        <label> {{ $c->contactnumber }}</label><br>


            </div>
@endforeach
            </div>
        </div>
    </div>
    <br>
    <!-- Footer -->
@include('.include/footer')
        <!-- /.container -->


    <!-- Bootstrap core JavaScript -->
    <script src="jquery/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>



</div>
</div>
</body>
</html>
