<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href= "<?php echo asset('css/login.css')?>"  type="text/css"  rel="stylesheet">
</head>
<body>
<center>
    <h1> admin login page</h1></center>
<div class="container">
    <form action="adminSection/dashboard" method="get">
        <div class="row">
            <div class="col">
                <div class="hide-md-lg login">


                <label>User Name</label>
                <input type="text" name="username" placeholder="Username" required>
                <label>Password</label>
                <input type="password" name="password" placeholder="Password" required>
                <input type="submit" value="Login">
            </div>

        </div>
    </form>
</div>

</body>
</html>
