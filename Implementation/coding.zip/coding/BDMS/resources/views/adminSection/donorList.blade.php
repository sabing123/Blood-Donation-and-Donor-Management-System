<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin-DonorList</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin Login Page</title>

    <!-- Bootstrap core CSS -->
    <link href="{{ url('css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="{{ url('/css/login.css') }}" type="text/css"  rel="stylesheet">

    <link href="{{ url('css/admin/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">


    <!-- Custom styles for this template -->



</head>
<body>

<?php include ('C:\xampp\htdocs\BDMS\public\admin.php');?><br>


<div class="content-wrapper">
    <div class="container-fluid">

        <div class="row">
            <div class="col-md-12 mainlist">

                <h2 class="page-title">Donors List</h2><hr>

                <!-- Zero Configuration Table -->
                <div class="panel panel-default">
                    <div class="panel-heading">Donors Info</div>
                    <div class="panel-body">
                        @include('./include/message')
                        <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="90%">
                            <thead>
                            <tr>

                                <th>#</th>
                                <th>Full Name</th>
                                <th>Blood Group</th>
                                <th>Address</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Mobile No.</th>
                                <th>Email</th>
                                <th>action </th>
                            </tr>
                            </thead>
                            <tfoot>
                            <tr>
                                <th>#</th>
                                <th>Full Name</th>
                                <th>Blood Group</th>
                                <th>Address</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Mobile No.</th>
                                <th>Email</th>
                                <th>action </th>
                            </tr>
                            </tfoot>
                            <tbody>

                            @foreach ($users as $donor)
                                <tr>
                                    <td>{{$count++}}</td>
                                    <td>{{ $donor->first_name }} {{ $donor->last_name }}</td>
                                    <td>{{ $donor->blood_group }}</td>
                                    <td>{{ $donor->address }}</td>
                                    <td>{{ $donor->age }}</td>
                                    <td>{{ $donor->gender }}</td>
                                    <td>{{ $donor->phone_number }}</td>
                                    <td>{{ $donor->email }}</td>

                                    <td>
                                    {{--@if($donor->status==1)--}}
                                    {{--{<a href= "#"> Make Hidden</a>}--}}
                                    {{--@else--}}
                                    {{--{--}}
                                    {{--<a href="#"> Make Public</a>--}}
                                     {{--}--}}
<br>
                                    <a href="donorList/{{ $donor->id }}" onclick="return confirm('Do you want to delete');"> Delete</a>
                                </td>

                            </tr>
                            @endforeach
                            </tbody>
                        </table>



                    </div>
                </div>



            </div>
        </div>

    </div>
</div>
</div>
<!-- Bootstrap core JavaScript -->

<!-- Bootstrap core JavaScript -->
{{--<script src="../../../public/jquery/jquery.js"></script>--}}

{{--<script src="../../../public/js/bootstrap.bundle.min.js"></script>--}}

<!-- Loading Scripts -->
{{--<script src="js/jquery.min.js"></script>--}}
{{--<script src="js/bootstrap-select.min.js"></script>--}}
{{--<script src="js/bootstrap.min.js"></script>--}}
{{--<script src="js/jquery.dataTables.min.js"></script>--}}
{{--<script src="js/dataTables.bootstrap.min.js"></script>--}}
{{--<script src="js/Chart.min.js"></script>--}}
{{--<script src="js/fileinput.js"></script>--}}
{{--<script src="js/chartData.js"></script>--}}
{{--<script src="js/main.js"></script>--}}

{{--<script>--}}


<script src="{{ url('C:\xampp\htdocs\BDMS\public\jquery\jquery.js') }}"></script>
<script src="{{ url('C:\xampp\htdocs\BDMS\public\js\bootstrap.bundle.js') }}"></script>
</body>
</html>
