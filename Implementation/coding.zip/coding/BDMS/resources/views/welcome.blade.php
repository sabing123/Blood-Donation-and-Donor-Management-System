<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Home Page</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>BDMS-Home Page</title>

        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/shop-homepage.css" rel="stylesheet">


    </head>
    <body>
        <div class="flex-center position-ref full-height">

                <?php include ('navigation.php');?>
                <div class="container">

                    <div class="row">

                        <div class="col-lg-12">
                            <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">

                                <div class="carousel-inner" role="listbox">
                                    <div class="carousel-item">
                                        <img class="d-block img-fluid" src="images/b1.jpg" alt="First slide">
                                    </div>
                                    <div class="carousel-item active">
                                        <img class="d-block img-fluid" src="images/b2.jpg" alt="Second slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block img-fluid" src="images/b3.jpg" alt="Third slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="d-block img-fluid" src="images/b4.jpg" alt="fourth slide">
                                    </div>
                                </div>
                                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>

                                </a>
                                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Page Content -->
                <div class="container">

                    <div class="row">

                        <div class="col-lg-4">

                            <h1 class="my-4">Blood Details</h1>
                            <div class="list-group">
                                <h6 class="list-group-item"><b>Blood Group A</b> has only A antigen on red cells (and B antibody in the plasma).</h6>
                                <h6 class="list-group-item"><b>Blood Group B</b> has only B antigen on red cells (and A antibody in the plasma).</h6>
                                <h6 class="list-group-item"> <b>Blood Group AB</b> has both A and B antigens on red cells (but neither A nor B antibody in the plasma)</h6>
                                <h6 class="list-group-item"> <b>Blood Group O </b> has neither A nor B antigens on red cells (but both A and B antibody are in the plasma)</h6>
                            </div>


                            <h3 class="my-4">WHO CAN DONATE</h3>
                            <div class="list-group">
                                <h6 class="list-group-item"><b>Accident & Injury– </b>  Can donate if otherwise healthy..</h6>
                                <h6 class="list-group-item"><b>Accupunture – </b>  Postpone donation for one year.</h6>
                                <h6 class="list-group-item"> <b>Aids – </b>Cannot donate</h6>
                                <h6 class="list-group-item"> <b>Allergies – </b>  Can donate if mild and require no treatment.</h6>
                                <h6 class="list-group-item"> <b>Blood Pressure – </b> Acceptable range is 160/90 to 110/70. Not to donate if on medication.</h6>
                                <h6 class="list-group-item"> <b>Cancer – </b>  Cannot donate.</h6>
                                <a href ="candonateinfo"><h6 class="list-group-item"  style="font-size: 20px; text-decoration: none;"> more &#8702; </h6></a>
                            </div>

                        </div>
                        <!-- /.col-lg-3 -->

                        <div class="col-lg-8">

                            <header>
                                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>

                                    </ol>
                                    <div class="carousel-inner" role="listbox">
                                        <!-- Slide One - Set the background image for this slide in the line below -->
                                        <div class="carousel-item active" style="background-image: url('public/images/b1.jpg')">
                                            <div class="carousel-caption d-none d-md-block">

                                            </div>
                                        </div>
                                        <!-- Slide Two - Set the background image for this slide in the line below -->
                                        <div class="carousel-item" style="background-image: url('images/banner2.jpg')">
                                            <div class="carousel-caption d-none d-md-block">
                                            </div>
                                        </div>

                                    </div>
                                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                            </header>
<br>

                            <h1>Latest Donor</h1>
                            <div class="row">
                                @foreach ($info as $don)

                                    <div class="col-lg-4 col-md-6 mb-4">
                                    <div class="card h-100">

                                        <a href="#"><img class="card-img-top" src="images/blood-donor.jpg" alt="blood-donor"></a>

                                        <div class="card-body">
                                            <h4 class="card-title">

                                                <a href="#">{{ $don->first_name }} {{ $don->last_name }}</a>
                                            </h4>
                                            <h6><b>Gender:</b> {{ $don->gender }}</h6>
                                            <h6><b>Blood Group:</b> {{ $don->blood_group }}</h6>
                                            <h6><b>Location:</b> {{ $don->address }}</h6>
                                            <h6><b>Contact No:</b> {{ $don->phone_number }}</h6>
                                        </div>

                                        <div class="card-footer">
                                            <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>

                                        </div>
                                    </div>
                                    </div>
                                @endforeach
                            </div>

                        </div>
                        <!-- /.row -->
                        <div style="border: 1px solid black; padding: 10px; text-align: justify;">
                        <h1> PERIOD & QUANTITY</h1>
                        <p >
                            One can not donate blood more than four times a year and for
                            females it is recommended to donate blood only two times a year.
                            It is also recommended that one should not donate more than 400ml
                            of blood at one time. After each withdrawal of blood,
                            it takes 36 hours for the body to reconstitute the fluid volume and
                            21 days for the blood cell count to return to normal level.
                        </p>

                        </div>
<br>
                        <div style="border: 1px solid black; padding: 10px; text-align: justify;">
                            <h1> WHO CANNOT DONATE</h1>
                            <p >
                                Blood donation is prohibited for persons with following health problems.
                                Tuberculosis, Sexually Transferable diseases, Diabetes, Asthma, High Blood pressure,
                                Kidney problems, Heart diseases, Jaundice, Fever, AIDS.
<br>
                                Also if the person is taking medicine for long time or addicted to any drugs,
                                s/he is prohibited for donating blood. Incase of females, one can not donate
                                during her periods, pregnancy and also during breast feeding.
                                <br>
                            </p>

                        </div>
                        <br>
                        <div style="border: 1px solid black; padding: 10px; text-align: justify;">
                            <h4>
                                SAVE LIFE SO THEREFORE THE RECIPIENT SHOULD
                                BENEFIT FROM DONATION AND THE DONOR SHOULD
                                NOT SUFFER.
                                <a href ="donor" style="text-decoration: none; margin-left: 650px; :white; color:black; border: 1px solid black; border-radius: 3px" > Become A donor</a>
                            </h4>

                        </div>


                    </div>
                    <!-- /.col-lg-9 -->

                </div>
                <!-- /.row -->

        </div>
<br>


        <!-- /.container -->


        <!-- Footer Elements -->
        <!-- Footer -->
        @include('.include/footer')
            <!-- /.container -->

        <!-- Bootstrap core JavaScript -->
        <script src="jquery/jquery.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>



        </div>
        </div>
    </body>
</html>
